# Tutors Ladder: rung 3 (layers), the standard version

This is the completed code for rung 3 of the Tutors Ladder. Build your own work on top of it.

- `rung-3-layers/`: the variant. Start with its README.md, then RUNG.md and AGENTS.md.
- `fixtures/`: the sample course every rung's tests use, and its upstream tutors.json.

Keep the two folders side by side: the tests find the fixture at `../fixtures`.
