# Tutors Ladder: rung 4 (proven), the standard version

This is the completed code for rung 4 of the Tutors Ladder. Build your own work on top of it.

- `rung-4-proven/`: the variant. Start with its README.md, then RUNG.md and AGENTS.md.
- `fixtures/`: the sample course every rung's tests use, and its upstream tutors.json.

Keep the two folders side by side: the tests find the fixture at `../fixtures`.
