# Tutors Ladder: rung 1 (seed), the standard version

This is the completed code for rung 1 of the Tutors Ladder. Build your own work on top of it.

- `rung-1-seed/`: the variant. Start with its README.md, then RUNG.md and AGENTS.md.
- `fixtures/`: the sample course every rung's tests use, and its upstream tutors.json.

Keep the two folders side by side: the tests find the fixture at `../fixtures`.
